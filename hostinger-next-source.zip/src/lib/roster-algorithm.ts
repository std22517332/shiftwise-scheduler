
import { DailySchedule, ShiftAssignment } from '@/ai/flows/generate-staff-roster-flow';
import { Staff } from '@/lib/types';
import { format, addDays, parseISO, eachDayOfInterval, getDay } from 'date-fns';

/**
 * CORE ROSTER LOGIC V48.0 - Perfect Dynamic Rotation
 */

const DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

const DAY_MAP: Record<string, number> = {
  'Monday': 0, 'Tuesday': 1, 'Wednesday': 2, 'Thursday': 3, 'Friday': 4, 'Saturday': 5, 'Sunday': 6
};

/**
 * Generates the roster with weekly forward rotation (one day per week).
 */
export function generateLocalRoster(
  staffList: Staff[],
  holidays: string[],
  extraPeakDays: string[],
  startDateStr: string,
  endDateStr: string,
  initialWeekOffset: number = 0,
  offIndexOverrides?: Record<string, number>
): { generatedSchedule: DailySchedule[]; warnings: string[] } {
  const startDate = parseISO(startDateStr);
  const endDate = parseISO(endDateStr);
  const days = eachDayOfInterval({ start: startDate, end: endDate });
  
  const schedule: DailySchedule[] = [];
  const warnings: string[] = [];
  const getRequiredWeeklyOff = (staff: Staff): 1 | 1.5 => {
    if (staff.weeklyOffDays === 1 || staff.weeklyOffDays === 1.5) return staff.weeklyOffDays;
    return staff.department === 'Housekeeping' ? 1 : 1.5;
  };
  const housekeepingStaffCount = staffList.filter((s) => s.department === 'Housekeeping').length;
  if (housekeepingStaffCount > 0 && housekeepingStaffCount < 2) {
    warnings.push('Housekeeping has fewer than 2 staff members; minimum daily 2-person presence cannot be met.');
  }

  // Tracks rotational night count for fairness within the block
  const nightShiftCounter: Record<string, number> = {};
  staffList.forEach(s => nightShiftCounter[s.name] = 0);

  // Monthly guaranteed OFF fairness pool:
  // fairness is isolated per (department + guaranteed day),
  // so departments do not affect each other.
  const monthlyGuaranteedGroups: Record<string, Staff[]> = {};
  staffList.forEach((staff) => {
    if (staff.guaranteedOffFrequency !== 'monthly' || !staff.guaranteedOffDay) return;
    const key = `${staff.department}__${staff.guaranteedOffDay}`;
    if (!monthlyGuaranteedGroups[key]) monthlyGuaranteedGroups[key] = [];
    monthlyGuaranteedGroups[key].push(staff);
  });

  // Phase 1: Determine pattern-based shifts
  days.forEach((day, dayIdx) => {
    const dateStr = format(day, 'yyyy-MM-dd');
    const weekIdx = Math.floor(dayIdx / 7) + initialWeekOffset;
    const dayInWeekIdx = (getDay(day) + 6) % 7; // Convert to Mon=0...Sun=6

    const dailyAssignments: ShiftAssignment[] = staffList.map((staff, staffIdx) => {
      const requiredWeeklyOff = getRequiredWeeklyOff(staff);
      // Dynamic fairness baseline:
      // - For up to 7 staff: one unique OFF slot per day in a week.
      // - For more than 7 staff: continue the same 7-day cycle (8th starts from Monday again, etc.).
      // Weekly rotation still advances by one day for everyone.
      const overrideOffIdx = offIndexOverrides?.[staff.name];
      const baseOffIdx = overrideOffIdx !== undefined ? overrideOffIdx : staffIdx % 7;
      let rotatedDayOffIdx = (baseOffIdx + weekIdx) % 7;

      // Guaranteed OFF options:
      // - weekly: always OFF on configured day
      // - monthly: once every 4 weeks, rotated fairly within the same department
      if (staff.guaranteedOffDay && DAY_MAP[staff.guaranteedOffDay] !== undefined) {
        const guaranteedIdx = DAY_MAP[staff.guaranteedOffDay];
        if (staff.guaranteedOffFrequency === 'weekly') {
          rotatedDayOffIdx = guaranteedIdx;
        } else if (staff.guaranteedOffFrequency === 'monthly') {
          const groupKey = `${staff.department}__${staff.guaranteedOffDay}`;
          const group = monthlyGuaranteedGroups[groupKey] || [];
          const staffOrder = group.findIndex((s) => s.name === staff.name);
          if (staffOrder !== -1) {
            const isMonthlyTurn = ((weekIdx + staffOrder) % 4) === 0;
            if (isMonthlyTurn) rotatedDayOffIdx = guaranteedIdx;
          }
        }
      }
      
      // 3-day gap between Full OFF and Half OFF
      const rotatedHalfOffIdx = (rotatedDayOffIdx + 4) % 7; 

      let shiftType: 'Day' | 'Night' | 'OFF' | 'H1-OFF' | 'H2-OFF' = 'Day';

      // Assign rest days
      if (dayInWeekIdx === rotatedDayOffIdx) {
        shiftType = 'OFF';
      } else if (requiredWeeklyOff === 1.5 && dayInWeekIdx === rotatedHalfOffIdx) {
        shiftType = 'H1-OFF';
      } else {
        // Set default based on preference
        if (staff.shiftPreference === 'StudentFixed') {
          if (staff.studentPatternMode === 'summer') {
            shiftType = 'Day';
          } else {
            const todayName = DAY_NAMES[dayInWeekIdx] as keyof NonNullable<Staff['studentWeeklyPattern']>;
            const patternValue = staff.studentWeeklyPattern?.[todayName];
            shiftType = patternValue === 'Night' ? 'Night' : 'Day';
          }
        } else {
          shiftType = staff.shiftPreference === 'Night' ? 'Night' : 'Day';
        }
      }

      // Night connectivity logic for Rotational/Night staff
      // A Night shift is assigned the day BEFORE any rest period
      const tomorrowInWeekIdx = (dayInWeekIdx + 1) % 7;
      const isTomorrowRest = (tomorrowInWeekIdx === rotatedDayOffIdx || tomorrowInWeekIdx === rotatedHalfOffIdx);
      
      if (isTomorrowRest && staff.shiftPreference !== 'Day' && staff.shiftPreference !== 'StudentFixed' && shiftType !== 'OFF') {
        shiftType = 'Night';
      }

      // Absolute Protection: Fixed Day preference staff NEVER assigned Night
      if (staff.shiftPreference === 'Day' && shiftType === 'Night') {
        shiftType = 'Day';
      }

      if (shiftType === 'Night') nightShiftCounter[staff.name]++;

      return {
        staffName: staff.name,
        department: staff.department,
        isSenior: staff.isSenior,
        shiftType: shiftType as any
      };
    });

    schedule.push({
      date: dateStr,
      dayOfWeek: DAY_NAMES[dayInWeekIdx],
      isPeakDay: [4, 5, 6].includes(dayInWeekIdx) || holidays.includes(dateStr) || extraPeakDays.includes(dateStr),
      assignments: dailyAssignments
    });
  });

  // Phase 2: Keep default night staffing at exactly 2 people (when possible)
  schedule.forEach((day) => {
    const nightAssignments = day.assignments.filter((a) => a.shiftType.includes('Night'));
    const currentNightCount = nightAssignments.length;

    // If more than 2 are assigned to Night, trim extras by fairness
    // while protecting fixed-pattern staff (Night + StudentFixed) as much as possible.
    if (currentNightCount > 2) {
      const preferredRemovable = nightAssignments.filter((a) => {
        const staff = staffList.find((s) => s.name === a.staffName);
        return staff?.shiftPreference !== 'Night' && staff?.shiftPreference !== 'StudentFixed';
      });
      const protectedNight = nightAssignments.filter((a) => {
        const staff = staffList.find((s) => s.name === a.staffName);
        return staff?.shiftPreference === 'Night';
      });

      const removePool = preferredRemovable.length >= (currentNightCount - 2)
        ? preferredRemovable
        : [...preferredRemovable, ...protectedNight];
      removePool.sort((a, b) => (nightShiftCounter[b.staffName] || 0) - (nightShiftCounter[a.staffName] || 0));

      const toRemove = currentNightCount - 2;
      for (let i = 0; i < Math.min(toRemove, removePool.length); i++) {
        const target = removePool[i];
        target.shiftType = 'Day' as any;
        nightShiftCounter[target.staffName] = Math.max(0, (nightShiftCounter[target.staffName] || 0) - 1);
      }
    }

    // If fewer than 2, add from Reservation + Rotational pool first.
    const updatedNightCount = day.assignments.filter((a) => a.shiftType.includes('Night')).length;
    if (updatedNightCount < 2) {
      const needed = 2 - updatedNightCount;

      const rotationalReservationCandidates = day.assignments.filter((a) => {
        const staff = staffList.find((s) => s.name === a.staffName);
        return !!staff && staff.department === 'Reservation' && staff.shiftPreference === 'Rotational' && a.shiftType === 'Day';
      });

      const fallbackCandidates = day.assignments.filter((a) => {
        const staff = staffList.find((s) => s.name === a.staffName);
        return !!staff && staff.shiftPreference === 'Rotational' && a.shiftType === 'Day';
      });

      const pool = rotationalReservationCandidates.length >= needed
        ? rotationalReservationCandidates
        : [...rotationalReservationCandidates, ...fallbackCandidates.filter((a) => !rotationalReservationCandidates.some((r) => r.staffName === a.staffName))];

      // Fairness: those with fewer nights are selected first.
      pool.sort((a, b) => (nightShiftCounter[a.staffName] || 0) - (nightShiftCounter[b.staffName] || 0));

      for (let i = 0; i < Math.min(needed, pool.length); i++) {
        const target = pool[i];
        target.shiftType = 'Night' as any;
        nightShiftCounter[target.staffName]++;
      }
    }
  });

  // Phase 3: Housekeeping minimum coverage (at least 2 people present each day, by default)
  const housekeepingForcedCoverCounter: Record<string, number> = {};
  staffList
    .filter((s) => s.department === 'Housekeeping')
    .forEach((s) => {
      housekeepingForcedCoverCounter[s.name] = 0;
    });

  schedule.forEach((day) => {
    const housekeepingAssignments = day.assignments.filter((a) => a.department === 'Housekeeping');
    if (housekeepingAssignments.length === 0) return;

    let presentCount = housekeepingAssignments.filter((a) => a.shiftType === 'Day').length;
    if (presentCount >= 2) return;

    const needed = 2 - presentCount;
    const convertible = housekeepingAssignments
      .filter((a) => a.shiftType === 'OFF' || a.shiftType.includes('H'))
      .sort((a, b) => (housekeepingForcedCoverCounter[a.staffName] || 0) - (housekeepingForcedCoverCounter[b.staffName] || 0));

    for (let i = 0; i < Math.min(needed, convertible.length); i++) {
      convertible[i].shiftType = 'Day' as any;
      housekeepingForcedCoverCounter[convertible[i].staffName] = (housekeepingForcedCoverCounter[convertible[i].staffName] || 0) + 1;
      presentCount++;
    }

    if (presentCount < 2) {
      warnings.push(`Housekeeping minimum coverage not met on ${day.date} (present: ${presentCount}, required: 2).`);
    }
  });

  return { generatedSchedule: schedule, warnings };
}
