import React, { useState, useEffect, useMemo } from 'react';
import { Staff } from '@/lib/types';
import { getStore, updateStaff } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { UserPlus, Edit2, Trash2, ShieldCheck, Shield } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

type SortField = 'department' | 'shiftPreference' | 'name';

export function StaffView() {
  const weekDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'] as const;
  const [staffList, setStaffList] = useState<Staff[]>([]);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editingStaff, setEditingStaff] = useState<Staff | null>(null);
  const [selectedShiftPreference, setSelectedShiftPreference] = useState<Staff['shiftPreference']>('Rotational');
  const [selectedDepartment, setSelectedDepartment] = useState<Staff['department']>('Reservation');
  const [nameError, setNameError] = useState('');
  const [primarySort, setPrimarySort] = useState<SortField>('department');
  const [secondarySort, setSecondarySort] = useState<SortField>('shiftPreference');
  const [staffToDelete, setStaffToDelete] = useState<Staff | null>(null);
  const { toast } = useToast();
  const selectedOffDays = editingStaff?.weeklyOffDays ?? (selectedDepartment === 'Housekeeping' ? 1 : 1.5);
  const departmentOrder: Staff['department'][] = ['Reservation', 'Housekeeping', 'QualityControl', 'Contracts'];
  const shiftOrder: Staff['shiftPreference'][] = ['Day', 'Rotational', 'Night', 'StudentFixed'];

  useEffect(() => {
    setStaffList(getStore().staff);
  }, []);

  const sortedStaffList = useMemo(() => {
    const compareByField = (a: Staff, b: Staff, field: SortField) => {
      if (field === 'department') return departmentOrder.indexOf(a.department) - departmentOrder.indexOf(b.department);
      if (field === 'shiftPreference') return shiftOrder.indexOf(a.shiftPreference) - shiftOrder.indexOf(b.shiftPreference);
      return a.name.localeCompare(b.name);
    };

    return [...staffList].sort((a, b) => {
      const primaryCompare = compareByField(a, b, primarySort);
      if (primaryCompare !== 0) return primaryCompare;

      const secondaryCompare = compareByField(a, b, secondarySort);
      if (secondaryCompare !== 0) return secondaryCompare;

      return a.name.localeCompare(b.name);
    });
  }, [staffList, primarySort, secondarySort]);

  const getWeeklyOffDays = (staff: Staff): 1 | 1.5 => {
    if (staff.weeklyOffDays === 1 || staff.weeklyOffDays === 1.5) return staff.weeklyOffDays;
    return staff.department === 'Housekeeping' ? 1 : 1.5;
  };

  const sortOptions: { value: SortField; label: string }[] = [
    { value: 'department', label: 'Department' },
    { value: 'shiftPreference', label: 'Shift Preference Type' },
    { value: 'name', label: 'Name' },
  ];

  const handleSave = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setNameError('');
    const formData = new FormData(e.currentTarget);
    const normalizeName = (value: unknown) => String(value ?? '').trim().toLowerCase();
    const staffName = String(formData.get('name') ?? '').trim();

    if (!staffName) {
      setNameError('Full name is required.');
      toast({
        title: 'خطا',
        description: 'نام را وارد کنید',
        variant: 'destructive',
      });
      return;
    }

    const isDuplicateName = staffList.some((staff) => {
      if (!staff || typeof staff !== 'object') return false;
      const isSameName = normalizeName((staff as Partial<Staff>).name) === normalizeName(staffName);
      if (!isSameName) return false;

      if (!editingStaff) return true;
      return (staff as Partial<Staff>).id !== editingStaff.id;
    });

    if (isDuplicateName) {
      setNameError('This name is taken');
      toast({
        title: 'خطا',
        description: 'نام درج شده تکراری هست',
        variant: 'destructive',
      });
      return;
    }

    const department = formData.get('department') as Staff['department'];
    const rawShiftPreference = formData.get('shiftPreference') as Staff['shiftPreference'];
    const weeklyOffDaysInput = Number(formData.get('weeklyOffDays'));
    const weeklyOffDays: 1 | 1.5 = weeklyOffDaysInput === 1 ? 1 : 1.5;
    const shiftPreference: Staff['shiftPreference'] = rawShiftPreference;

    const newStaff: Staff = {
      id: editingStaff?.id || Math.random().toString(36).substr(2, 9),
      name: staffName,
      department,
      shiftPreference,
      isSenior: formData.get('isSenior') === 'on',
      defaultOffDay: formData.get('defaultOffDay') as string,
      guaranteedOffDay: (formData.get('guaranteedOffDay') as any) || undefined,
      guaranteedOffFrequency: (formData.get('guaranteedOffFrequency') as any) || 'none',
      weeklyOffDays,
      studentPatternMode: shiftPreference === 'StudentFixed' ? ((formData.get('studentPatternMode') as any) || 'academic') : undefined,
      studentWeeklyPattern: shiftPreference === 'StudentFixed'
        ? weekDays.reduce((acc, day) => {
            const v = formData.get(`student_${day}`) as 'Day' | 'Night' | null;
            if (v) acc[day] = v;
            return acc;
          }, {} as any)
        : undefined,
    };

    const updatedList = editingStaff 
      ? staffList.map((s) => (s?.id === editingStaff.id ? newStaff : s))
      : [...staffList, newStaff];

    setStaffList(updatedList);
    updateStaff(updatedList);
    setIsAddOpen(false);
    setEditingStaff(null);
    setNameError('');
  };

  const removeStaff = (staff: Staff) => {
    const updated = staffList.filter(s => s.id !== staff.id);
    setStaffList(updated);
    updateStaff(updated);
    setStaffToDelete(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-headline font-bold text-foreground">Staff Directory</h2>
          <p className="text-muted-foreground text-sm">Manage your team profiles and preferences.</p>
        </div>
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => { setEditingStaff(null); setSelectedShiftPreference('Rotational'); setSelectedDepartment('Reservation'); setNameError(''); }} className="gap-2 bg-primary hover:bg-primary/90">
              <UserPlus className="w-4 h-4" /> Add Staff Member
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>{editingStaff ? 'Edit Staff Profile' : 'Add Staff Member'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSave} className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  name="name"
                  defaultValue={editingStaff?.name}
                  required
                  onChange={() => {
                    if (nameError) setNameError('');
                  }}
                  className={nameError ? 'border-red-500 focus-visible:ring-red-500' : ''}
                />
                {nameError ? <p className="text-sm text-red-600">{nameError}</p> : null}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="department">Department</Label>
                  <Select
                    name="department"
                    defaultValue={editingStaff?.department || "Reservation"}
                    onValueChange={(value) => setSelectedDepartment(value as Staff['department'])}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select dept" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Reservation">Reservation</SelectItem>
                      <SelectItem value="QualityControl">Quality Control</SelectItem>
                      <SelectItem value="Contracts">Contracts</SelectItem>
                      <SelectItem value="Housekeeping">Housekeeping</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="shiftPreference">Shift Type</Label>
                  <Select
                    name="shiftPreference"
                    defaultValue={editingStaff?.shiftPreference || "Rotational"}
                    onValueChange={(value) => setSelectedShiftPreference(value as Staff['shiftPreference'])}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select shift" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Day">Day</SelectItem>
                      <SelectItem value="Night">Night</SelectItem>
                      <SelectItem value="Rotational">Rotational</SelectItem>
                      <SelectItem value="StudentFixed">Student (Fixed Weekly)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              {selectedDepartment === 'Housekeeping' && (
                <p className="text-xs text-muted-foreground rounded-md border border-primary/20 bg-primary/5 p-2">
                  Housekeeping staff can use any shift type selected above. You can also choose 1 or 1.5 OFF days per week.
                </p>
              )}
              {selectedDepartment !== 'Housekeeping' && selectedShiftPreference === 'StudentFixed' && (
                <div className="space-y-3 rounded-lg border p-3 bg-muted/20">
                  <div className="space-y-2">
                    <Label htmlFor="studentPatternMode">Student Mode</Label>
                    <Select name="studentPatternMode" defaultValue={editingStaff?.studentPatternMode || "academic"}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select mode" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="academic">Academic Term</SelectItem>
                        <SelectItem value="summer">Summer (Day only)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    {weekDays.map((day) => (
                      <div key={day} className="space-y-1">
                        <Label htmlFor={`student_${day}`} className="text-xs">{day}</Label>
                        <Select name={`student_${day}`} defaultValue={editingStaff?.studentWeeklyPattern?.[day] || 'Day'}>
                          <SelectTrigger>
                            <SelectValue placeholder="Shift" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Day">Day</SelectItem>
                            <SelectItem value="Night">Night</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              <div className="space-y-2">
                <Label htmlFor="defaultOffDay">Preferred Default Off Day</Label>
                <Select name="defaultOffDay" defaultValue={editingStaff?.defaultOffDay || "Sunday"}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select day" />
                  </SelectTrigger>
                  <SelectContent>
                    {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map(day => (
                      <SelectItem key={day} value={day}>{day}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="weeklyOffDays">OFF Days Per Week</Label>
                <Select name="weeklyOffDays" defaultValue={String(selectedOffDays)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select weekly OFF" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 day</SelectItem>
                    <SelectItem value="1.5">1.5 days</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="guaranteedOffFrequency">Guaranteed OFF Rule</Label>
                  <Select name="guaranteedOffFrequency" defaultValue={editingStaff?.guaranteedOffFrequency || "none"}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select rule" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      <SelectItem value="weekly">Weekly (always)</SelectItem>
                      <SelectItem value="monthly">Monthly (once)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="guaranteedOffDay">Guaranteed OFF Day</Label>
                  <Select name="guaranteedOffDay" defaultValue={editingStaff?.guaranteedOffDay || "Sunday"}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select day" />
                    </SelectTrigger>
                    <SelectContent>
                      {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map(day => (
                        <SelectItem key={day} value={day}>{day}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex items-center space-x-2 pt-2">
                <input type="checkbox" id="isSenior" name="isSenior" defaultChecked={editingStaff?.isSenior} className="rounded border-input text-primary focus:ring-primary" />
                <Label htmlFor="isSenior" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                  Senior Experience (Expert)
                </Label>
              </div>
              <Button type="submit" className="w-full bg-primary mt-4">Save Staff Member</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
        <div className="p-4 border-b bg-muted/20 flex flex-wrap items-center gap-3">
          <div className="w-[210px]">
            <Label className="text-xs text-muted-foreground">Primary sort</Label>
            <Select
              value={primarySort}
              onValueChange={(value) => {
                const nextPrimary = value as SortField;
                setPrimarySort(nextPrimary);

                if (nextPrimary === secondarySort) {
                  const fallbackSecondary = sortOptions.find((option) => option.value !== nextPrimary)?.value ?? 'name';
                  setSecondarySort(fallbackSecondary);
                }
              }}
            >
              <SelectTrigger className="h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {sortOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="w-[210px]">
            <Label className="text-xs text-muted-foreground">Secondary sort</Label>
            <Select value={secondarySort} onValueChange={(v) => setSecondarySort(v as SortField)}>
              <SelectTrigger className="h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {sortOptions
                  .filter((option) => option.value !== primarySort)
                  .map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/30">
              <TableHead className="font-semibold">Name</TableHead>
              <TableHead className="font-semibold">Department</TableHead>
              <TableHead className="font-semibold">Seniority</TableHead>
              <TableHead className="font-semibold">Shift Pref</TableHead>
              <TableHead className="font-semibold">OFF/Week</TableHead>
              <TableHead className="font-semibold">Default Off</TableHead>
              <TableHead className="text-right font-semibold">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedStaffList.map((staff) => (
              <TableRow key={staff.id} className="hover:bg-muted/10 transition-colors">
                <TableCell className="font-medium">{staff.name}</TableCell>
                <TableCell>{staff.department}</TableCell>
                <TableCell>
                  {staff.isSenior ? (
                    <Badge className="bg-primary/10 text-primary border-primary/20 hover:bg-primary/20">
                      <ShieldCheck className="w-3 h-3 mr-1" /> Senior
                    </Badge>
                  ) : (
                    <Badge variant="secondary" className="bg-muted text-muted-foreground border-transparent">
                       <Shield className="w-3 h-3 mr-1" /> Junior
                    </Badge>
                  )}
                </TableCell>
                <TableCell>{staff.shiftPreference}</TableCell>
                <TableCell>{getWeeklyOffDays(staff)}</TableCell>
                <TableCell>{staff.defaultOffDay}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button variant="ghost" size="icon" onClick={() => { setEditingStaff(staff); setSelectedShiftPreference(staff.shiftPreference); setSelectedDepartment(staff.department); setNameError(''); setIsAddOpen(true); }} className="h-8 w-8 hover:text-primary">
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => setStaffToDelete(staff)} className="h-8 w-8 hover:text-destructive">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <AlertDialog open={!!staffToDelete} onOpenChange={(open) => { if (!open) setStaffToDelete(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Staff Member?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {staffToDelete?.name ? `"${staffToDelete.name}"` : 'this staff member'}?
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => { if (staffToDelete) removeStaff(staffToDelete); }} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
